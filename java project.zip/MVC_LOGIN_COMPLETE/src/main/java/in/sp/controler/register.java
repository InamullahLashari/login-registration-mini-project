package in.sp.controler;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import in.sp.dbmc.Cont_dbmc;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/reg")
public class register extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();
        resp.setContentType("text/html");

        String Name1 = req.getParameter("Name");
        String pass1 = req.getParameter("password");
        String roll1 = req.getParameter("Roll");
        String Num1= req.getParameter("Number");

        try {
            Connection con = Cont_dbmc.getConnection();
            // Fixed the typo from "inset" to "INSERT"
            String insertQuery = "INSERT INTO mvc_table (Name, password, roll,Numberr ) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(insertQuery);
            ps.setString(1, Name1);
            ps.setString(2, pass1);
            ps.setString(3, roll1);
            ps.setString(4, Num1);

            int i = ps.executeUpdate();

            if (i > 0) {
                out.println("<h3 style='color:green'>Registration successful!</h3>");
                RequestDispatcher rd = req.getRequestDispatcher("/login.html");
                rd.forward(req, resp);  // Changed to forward instead of include
            } else {
                out.println("<h3 style='color:red'>Connection failed!</h3>");
                RequestDispatcher rd = req.getRequestDispatcher("/register.html");
                rd.include(req, resp);  // Using include here
            }
        } catch (Exception e) {
            e.printStackTrace();
            out.println("<h3 style='color:red'>Err occurred: " + e.getMessage() + "</h3>");
        }
    }
}
