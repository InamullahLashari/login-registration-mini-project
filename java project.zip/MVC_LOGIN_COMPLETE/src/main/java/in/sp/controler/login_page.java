package in.sp.controler;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import in.sp.dbmc.Cont_dbmc;
import in.sp.model.modell;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/log")
public class login_page extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();
        resp.setContentType("text/html");
        String E_name = req.getParameter("Name");
        String pas_word = req.getParameter("password");

        try {
            Connection con = Cont_dbmc.getConnection();
            
            // Correct query and parameter order
            String insertQuery = "SELECT * FROM mvc.mvc_table WHERE Name=? AND Password=?";
            PreparedStatement ps = con.prepareStatement(insertQuery);
            ps.setString(1, E_name);  // Name
            ps.setString(2, pas_word); // Password
           

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                // Populate the model object
                modell model = new modell();
                model.setName(rs.getString("Name")); // Ensure column names match the database
                model.setRoll(rs.getString("roll"));
                model.setNumbers(rs.getString("Numberr"));

                // Set session attribute
                HttpSession session = req.getSession();
                session.setAttribute("session_model", model);

                // Forward to profile.jsp
                RequestDispatcher rd = req.getRequestDispatcher("/profile.jsp");
                rd.forward(req, resp);
            } else {
            	

                // Handle invalid credentials
                out.println("<h3 style='color:red'>Email and password didn't match</h3>");
                RequestDispatcher rd = req.getRequestDispatcher("/login.html");
                rd.include(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.getWriter().println("<h3>Error occurred: " + e.getMessage() + "</h3>");
        }
    }
}
