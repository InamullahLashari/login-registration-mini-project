package in.sp.dbmc;

import java.sql.Connection;
import java.sql.DriverManager;

public class Cont_dbmc {

    // Method to establish and return a database connection
    public static Connection getConnection() {
        Connection con = null; // Initialize the connection object
        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/mvc", // Correct JDBC URL
                "root", // Database username
                "pasword" // Database password
            );

        } catch (Exception e) {
            e.printStackTrace(); // Print stack trace for debugging
        }

        return con; // Return the connection object
    }
}
